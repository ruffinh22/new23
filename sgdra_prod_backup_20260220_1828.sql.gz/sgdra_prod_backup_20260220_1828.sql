/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.9-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: sgdra_prod
-- ------------------------------------------------------
-- Server version	10.11.9-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(50) NOT NULL,
  `severity` varchar(20) NOT NULL,
  `object_id` int(10) unsigned DEFAULT NULL CHECK (`object_id` >= 0),
  `description` longtext NOT NULL,
  `changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`changes`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` longtext NOT NULL,
  `success` tinyint(1) NOT NULL,
  `error_message` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `actor_id` bigint(20) DEFAULT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_content_type_id_47a353b2_fk_django_content_type_id` (`content_type_id`),
  KEY `audit_logs_actor_i_3b0e80_idx` (`actor_id`,`created_at` DESC),
  KEY `audit_logs_action_bcaa71_idx` (`action`,`created_at` DESC),
  KEY `audit_logs_created_262184_idx` (`created_at`),
  KEY `audit_logs_severit_fc52cc_idx` (`severity`),
  CONSTRAINT `audit_logs_actor_id_303d1495_fk_users_id` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `audit_logs_content_type_id_47a353b2_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',0,'','2026-02-17 14:17:26.954316',14,NULL),
(2,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',0,'','2026-02-17 14:29:54.758050',11,NULL),
(3,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',0,'','2026-02-17 14:40:21.506122',11,NULL),
(4,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',0,'','2026-02-17 14:42:51.466505',14,NULL),
(5,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',0,'','2026-02-17 14:46:54.272027',11,NULL),
(6,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',0,'','2026-02-17 14:47:12.523610',14,NULL),
(7,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 14:48:33.831027',11,NULL),
(8,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',0,'','2026-02-17 14:48:49.684693',14,NULL),
(9,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',0,'','2026-02-17 14:48:51.861569',14,NULL),
(10,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',0,'','2026-02-17 14:49:33.401810',14,NULL),
(11,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','curl/8.16.0',0,'','2026-02-17 14:51:07.859311',11,NULL),
(12,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/file-type-configurations/xls/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 14:51:37.098015',11,NULL),
(13,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','curl/8.16.0',0,'','2026-02-17 14:54:16.895482',11,NULL),
(14,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','curl/8.16.0',1,'','2026-02-17 14:54:51.511406',11,NULL),
(15,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',1,'','2026-02-17 14:55:57.223633',14,NULL),
(16,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/file-type-configurations/xlsx/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 14:58:14.001583',11,NULL),
(17,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 15:04:28.412762',11,NULL),
(18,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/2/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 15:05:45.907522',11,NULL),
(19,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/3/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 15:18:34.523628',11,NULL),
(20,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/file-type-configurations/docx/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:36:58.247144',11,NULL),
(21,'DOCUMENT_UPLOAD','ERROR',NULL,'Ressource créé: /api/documents/file-type-configurations/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',0,'','2026-02-17 17:38:00.986308',NULL,NULL),
(22,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:38:53.484562',11,NULL),
(23,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:40:25.669965',11,NULL),
(24,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/csv/toggle_enabled/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:43:05.349271',11,NULL),
(25,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/csv/toggle_enabled/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:43:09.069786',11,NULL),
(26,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/csv/toggle_enabled/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:43:10.911383',11,NULL),
(27,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/docx/toggle_enabled/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:43:13.727935',11,NULL),
(28,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/docx/toggle_enabled/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:43:15.574048',11,NULL),
(29,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/csv/toggle_enabled/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:43:15.669542',11,NULL),
(30,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/file-type-configurations/docx/toggle_enabled/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 17:43:19.437367',11,NULL),
(31,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',1,'','2026-02-17 18:56:52.166154',13,NULL),
(32,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/4/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 19:00:34.446125',11,NULL),
(33,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',1,'','2026-02-17 19:25:26.863284',13,NULL),
(34,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/5/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-17 19:49:34.817034',11,NULL),
(35,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',1,'','2026-02-18 08:27:05.820917',13,NULL),
(36,'ADMIN_ROUTING_RULE_CREATE','ERROR',NULL,'Ressource créé: /api/routing-rules/document-types/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',0,'','2026-02-18 09:48:44.960712',11,NULL),
(37,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/specifications/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',1,'','2026-02-18 11:41:52.193783',11,NULL),
(38,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-18 11:50:46.305507',13,NULL),
(39,'ADMIN_ROUTING_RULE_CREATE','INFO',NULL,'Ressource créé: /api/routing-rules/document-types/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',1,'','2026-02-18 12:05:50.781971',11,NULL),
(40,'DOCUMENT_UPLOAD','INFO',NULL,'Ressource créé: /api/documents/ | Méthode: POST','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-18 12:06:44.364807',13,NULL),
(41,'ADMIN_FOLDER_UPDATE','INFO',NULL,'Ressource modifié: /api/folders/50/ | Méthode: PUT','{}','10.0.6.107','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',1,'','2026-02-20 09:57:00.273176',11,NULL),
(42,'ADMIN_FOLDER_UPDATE','ERROR',NULL,'Ressource modifié: /api/folders/50/ | Méthode: PUT','{}','10.0.6.107','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0,'','2026-02-20 10:02:21.833462',NULL,NULL),
(43,'ADMIN_FOLDER_UPDATE','ERROR',NULL,'Ressource modifié: /api/folders/50/ | Méthode: PUT','{}','10.0.6.107','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',0,'','2026-02-20 10:02:25.034777',NULL,NULL),
(44,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/6/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-20 11:22:19.357241',11,NULL),
(45,'DOCUMENT_UPDATE','INFO',NULL,'Ressource modifié: /api/documents/7/ | Méthode: PATCH','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-20 11:22:23.090263',11,NULL),
(46,'ADMIN_FOLDER_UPDATE','INFO',NULL,'Ressource modifié: /api/folders/50/ | Méthode: PUT','{}','10.0.6.107','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0',1,'','2026-02-20 11:24:33.811964',11,NULL),
(47,'ADMIN_FOLDER_DELETE','INFO',NULL,'Ressource supprimé: /api/folders/44/ | Méthode: DELETE','{}','10.0.6.49','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',1,'','2026-02-20 16:12:41.349034',11,NULL);
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can view log entry',1,'view_logentry'),
(5,'Can add permission',2,'add_permission'),
(6,'Can change permission',2,'change_permission'),
(7,'Can delete permission',2,'delete_permission'),
(8,'Can view permission',2,'view_permission'),
(9,'Can add group',3,'add_group'),
(10,'Can change group',3,'change_group'),
(11,'Can delete group',3,'delete_group'),
(12,'Can view group',3,'view_group'),
(13,'Can add content type',4,'add_contenttype'),
(14,'Can change content type',4,'change_contenttype'),
(15,'Can delete content type',4,'delete_contenttype'),
(16,'Can view content type',4,'view_contenttype'),
(17,'Can add session',5,'add_session'),
(18,'Can change session',5,'change_session'),
(19,'Can delete session',5,'delete_session'),
(20,'Can view session',5,'view_session'),
(21,'Can add crontab',6,'add_crontabschedule'),
(22,'Can change crontab',6,'change_crontabschedule'),
(23,'Can delete crontab',6,'delete_crontabschedule'),
(24,'Can view crontab',6,'view_crontabschedule'),
(25,'Can add interval',7,'add_intervalschedule'),
(26,'Can change interval',7,'change_intervalschedule'),
(27,'Can delete interval',7,'delete_intervalschedule'),
(28,'Can view interval',7,'view_intervalschedule'),
(29,'Can add periodic task',8,'add_periodictask'),
(30,'Can change periodic task',8,'change_periodictask'),
(31,'Can delete periodic task',8,'delete_periodictask'),
(32,'Can view periodic task',8,'view_periodictask'),
(33,'Can add periodic tasks',9,'add_periodictasks'),
(34,'Can change periodic tasks',9,'change_periodictasks'),
(35,'Can delete periodic tasks',9,'delete_periodictasks'),
(36,'Can view periodic tasks',9,'view_periodictasks'),
(37,'Can add solar event',10,'add_solarschedule'),
(38,'Can change solar event',10,'change_solarschedule'),
(39,'Can delete solar event',10,'delete_solarschedule'),
(40,'Can view solar event',10,'view_solarschedule'),
(41,'Can add clocked',11,'add_clockedschedule'),
(42,'Can change clocked',11,'change_clockedschedule'),
(43,'Can delete clocked',11,'delete_clockedschedule'),
(44,'Can view clocked',11,'view_clockedschedule'),
(45,'Can add task result',12,'add_taskresult'),
(46,'Can change task result',12,'change_taskresult'),
(47,'Can delete task result',12,'delete_taskresult'),
(48,'Can view task result',12,'view_taskresult'),
(49,'Can add chord counter',13,'add_chordcounter'),
(50,'Can change chord counter',13,'change_chordcounter'),
(51,'Can delete chord counter',13,'delete_chordcounter'),
(52,'Can view chord counter',13,'view_chordcounter'),
(53,'Can add group result',14,'add_groupresult'),
(54,'Can change group result',14,'change_groupresult'),
(55,'Can delete group result',14,'delete_groupresult'),
(56,'Can view group result',14,'view_groupresult'),
(57,'Can add Utilisateur',15,'add_user'),
(58,'Can change Utilisateur',15,'change_user'),
(59,'Can delete Utilisateur',15,'delete_user'),
(60,'Can view Utilisateur',15,'view_user'),
(61,'Can add Département',16,'add_department'),
(62,'Can change Département',16,'change_department'),
(63,'Can delete Département',16,'delete_department'),
(64,'Can view Département',16,'view_department'),
(65,'Can add Filiale',17,'add_branch'),
(66,'Can change Filiale',17,'change_branch'),
(67,'Can delete Filiale',17,'delete_branch'),
(68,'Can view Filiale',17,'view_branch'),
(69,'Can add Journal d\'audit',18,'add_auditlog'),
(70,'Can change Journal d\'audit',18,'change_auditlog'),
(71,'Can delete Journal d\'audit',18,'delete_auditlog'),
(72,'Can view Journal d\'audit',18,'view_auditlog'),
(73,'Can add Spécification de document',19,'add_documentspecification'),
(74,'Can change Spécification de document',19,'change_documentspecification'),
(75,'Can delete Spécification de document',19,'delete_documentspecification'),
(76,'Can view Spécification de document',19,'view_documentspecification'),
(77,'Can add Document',20,'add_document'),
(78,'Can change Document',20,'change_document'),
(79,'Can delete Document',20,'delete_document'),
(80,'Can view Document',20,'view_document'),
(81,'Can add Résultat de validation',21,'add_documentvalidationresult'),
(82,'Can change Résultat de validation',21,'change_documentvalidationresult'),
(83,'Can delete Résultat de validation',21,'delete_documentvalidationresult'),
(84,'Can view Résultat de validation',21,'view_documentvalidationresult'),
(85,'Can add Configuration Type Fichier',22,'add_filetypeconfiguration'),
(86,'Can change Configuration Type Fichier',22,'change_filetypeconfiguration'),
(87,'Can delete Configuration Type Fichier',22,'delete_filetypeconfiguration'),
(88,'Can view Configuration Type Fichier',22,'view_filetypeconfiguration'),
(89,'Can add Exigence Type Fichier',23,'add_filetyperequirement'),
(90,'Can change Exigence Type Fichier',23,'change_filetyperequirement'),
(91,'Can delete Exigence Type Fichier',23,'delete_filetyperequirement'),
(92,'Can view Exigence Type Fichier',23,'view_filetyperequirement'),
(93,'Can add document template',24,'add_documenttemplate'),
(94,'Can change document template',24,'change_documenttemplate'),
(95,'Can delete document template',24,'delete_documenttemplate'),
(96,'Can view document template',24,'view_documenttemplate'),
(97,'Can add template download log',25,'add_templatedownloadlog'),
(98,'Can change template download log',25,'change_templatedownloadlog'),
(99,'Can delete template download log',25,'delete_templatedownloadlog'),
(100,'Can view template download log',25,'view_templatedownloadlog'),
(101,'Can add template version',26,'add_templateversion'),
(102,'Can change template version',26,'change_templateversion'),
(103,'Can delete template version',26,'delete_templateversion'),
(104,'Can view template version',26,'view_templateversion'),
(105,'Can add Dossier',27,'add_folder'),
(106,'Can change Dossier',27,'change_folder'),
(107,'Can delete Dossier',27,'delete_folder'),
(108,'Can view Dossier',27,'view_folder'),
(109,'Can add Règle de routage',28,'add_routingrule'),
(110,'Can change Règle de routage',28,'change_routingrule'),
(111,'Can delete Règle de routage',28,'delete_routingrule'),
(112,'Can view Règle de routage',28,'view_routingrule'),
(113,'Can add Type de document par département',29,'add_departmentdocumenttype'),
(114,'Can change Type de document par département',29,'change_departmentdocumenttype'),
(115,'Can delete Type de document par département',29,'delete_departmentdocumenttype'),
(116,'Can view Type de document par département',29,'view_departmentdocumenttype'),
(117,'Can add Notification',30,'add_notification'),
(118,'Can change Notification',30,'change_notification'),
(119,'Can delete Notification',30,'delete_notification'),
(120,'Can view Notification',30,'view_notification');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branches` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `country_code` varchar(2) NOT NULL,
  `description` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `folder_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `country_code` (`country_code`),
  UNIQUE KEY `folder_id` (`folder_id`),
  CONSTRAINT `branches_folder_id_39148d3b_fk_folders_id` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES
(1,'Bénin','BEN','BJ','Filiale du Bénin',1,'2026-02-17 11:44:23.699612','2026-02-17 11:44:23.699645',1),
(2,'Congo','CON','CG','Filiale du Congo',1,'2026-02-17 11:44:28.120526','2026-02-17 11:44:28.120609',2),
(3,'Côte d\'Ivoire','CIV','CI','Filiale de Côte d\'Ivoire',1,'2026-02-17 11:44:33.844362','2026-02-17 11:44:33.844501',3),
(4,'Cameroun','CAM','CM','Filiale du Cameroun',1,'2026-02-17 11:44:35.457524','2026-02-17 11:44:35.457597',4),
(5,'Guinée Équatoriale','GEQ','GQ','Filiale de Guinée Équatoriale',1,'2026-02-17 11:44:36.878613','2026-02-17 11:44:36.878686',5),
(6,'Guinée','GUI','GN','Filiale de Guinée (Conakry)',1,'2026-02-17 11:44:37.752342','2026-02-17 11:44:37.752414',6),
(7,'Guinée-Bissau','GBS','GW','Filiale de Guinée-Bissau',1,'2026-02-17 11:44:45.069485','2026-02-17 11:44:45.069558',7);
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department_document_types`
--

DROP TABLE IF EXISTS `department_document_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department_document_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `department` varchar(50) NOT NULL,
  `document_type` varchar(50) NOT NULL,
  `is_available` tinyint(1) NOT NULL,
  `description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `target_folder_id` bigint(20) DEFAULT NULL,
  `file_type_configuration_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `department_document_types_department_document_type_1a803637_uniq` (`department`,`document_type`),
  KEY `department_document__target_folder_id_248cc926_fk_folders_i` (`target_folder_id`),
  KEY `department_document__file_type_configurat_d628a2cf_fk_file_type` (`file_type_configuration_id`),
  CONSTRAINT `department_document__file_type_configurat_d628a2cf_fk_file_type` FOREIGN KEY (`file_type_configuration_id`) REFERENCES `file_type_configurations` (`id`),
  CONSTRAINT `department_document__target_folder_id_248cc926_fk_folders_i` FOREIGN KEY (`target_folder_id`) REFERENCES `folders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department_document_types`
--

LOCK TABLES `department_document_types` WRITE;
/*!40000 ALTER TABLE `department_document_types` DISABLE KEYS */;
INSERT INTO `department_document_types` VALUES
(1,'Commercial','FACTURE',1,'','2026-02-17 14:38:09.417932','2026-02-17 14:38:09.418034',14,NULL),
(2,'Commercial','BON_COMMANDE',1,'','2026-02-17 14:38:10.580134','2026-02-17 14:38:10.580216',15,NULL),
(3,'Commercial','CONTRAT',1,'','2026-02-17 14:38:12.438391','2026-02-17 14:38:12.438472',16,NULL),
(4,'Commercial','RAPPORT',1,'','2026-02-17 14:38:13.470923','2026-02-17 14:38:13.471002',17,NULL),
(5,'Commercial','AUTRE',1,'','2026-02-17 14:38:15.345669','2026-02-17 14:38:15.345744',18,NULL),
(6,'Direction','FACTURE',1,'','2026-02-17 14:38:17.195547','2026-02-17 14:38:17.195622',19,NULL),
(7,'Direction','BON_COMMANDE',1,'','2026-02-17 14:38:17.295199','2026-02-17 14:38:17.295273',20,NULL),
(8,'Direction','CONTRAT',1,'','2026-02-17 14:38:17.520498','2026-02-17 14:38:17.520577',21,NULL),
(9,'Direction','RAPPORT',1,'','2026-02-17 14:38:19.387343','2026-02-17 14:38:19.387424',22,NULL),
(10,'Direction','AUTRE',1,'','2026-02-17 14:38:20.953749','2026-02-17 14:38:20.953825',23,NULL),
(11,'Finance','FACTURE',1,'','2026-02-17 14:38:22.595396','2026-02-17 14:38:22.595473',24,NULL),
(12,'Finance','BON_COMMANDE',1,'','2026-02-17 14:38:26.461724','2026-02-17 14:38:26.461802',25,NULL),
(13,'Finance','CONTRAT',1,'','2026-02-17 14:38:27.803619','2026-02-17 14:38:27.803698',26,NULL),
(14,'Finance','RAPPORT',1,'','2026-02-17 14:38:28.303490','2026-02-17 14:38:28.303569',27,NULL),
(15,'Finance','AUTRE',1,'','2026-02-17 14:38:28.530137','2026-02-17 14:38:28.530214',28,NULL),
(16,'Logistique','FACTURE',1,'','2026-02-17 14:38:28.770244','2026-02-17 14:38:28.770324',29,NULL),
(17,'Logistique','BON_COMMANDE',1,'','2026-02-17 14:38:28.995402','2026-02-17 14:38:28.995484',30,NULL),
(18,'Logistique','CONTRAT',1,'','2026-02-17 14:38:30.846050','2026-02-17 14:38:30.846129',31,NULL),
(19,'Logistique','RAPPORT',1,'','2026-02-17 14:38:31.133725','2026-02-17 14:38:31.133760',32,NULL),
(20,'Logistique','AUTRE',1,'','2026-02-17 14:38:31.176010','2026-02-17 14:38:31.176069',33,NULL),
(21,'Ressources Humaines','FACTURE',1,'','2026-02-17 14:38:31.970904','2026-02-17 14:38:31.971004',34,NULL),
(22,'Ressources Humaines','BON_COMMANDE',1,'','2026-02-17 14:38:32.061927','2026-02-17 14:38:32.062004',35,NULL),
(23,'Ressources Humaines','CONTRAT',1,'','2026-02-17 14:38:32.266175','2026-02-17 14:38:32.266201',36,NULL),
(24,'Ressources Humaines','RAPPORT',1,'','2026-02-17 14:38:33.650234','2026-02-17 14:38:33.650266',37,NULL),
(25,'Ressources Humaines','AUTRE',1,'','2026-02-17 14:38:35.486694','2026-02-17 14:38:35.486774',38,NULL),
(26,'Technique','FACTURE',1,'','2026-02-17 14:38:37.345250','2026-02-17 14:38:37.345460',39,NULL),
(27,'Technique','BON_COMMANDE',1,'','2026-02-17 14:38:37.986959','2026-02-17 14:38:37.987038',40,NULL),
(28,'Technique','CONTRAT',1,'','2026-02-17 14:38:38.528800','2026-02-17 14:38:38.528876',41,NULL),
(29,'Technique','RAPPORT',1,'','2026-02-17 14:38:41.969726','2026-02-17 14:38:41.969802',42,NULL),
(30,'Technique','AUTRE',1,'','2026-02-17 14:38:42.232819','2026-02-17 14:38:42.232844',43,NULL),
(31,'RH','CONGE',1,'','2026-02-18 12:05:47.627914','2026-02-18 12:05:47.627990',48,NULL);
/*!40000 ALTER TABLE `department_document_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `description` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `folder_id` bigint(20) DEFAULT NULL,
  `branch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folder_id` (`folder_id`),
  UNIQUE KEY `departments_branch_id_code_1cc62bb8_uniq` (`branch_id`,`code`),
  CONSTRAINT `departments_branch_id_a7dda1c5_fk_branches_id` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `departments_folder_id_79e50572_fk_folders_id` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES
(1,'Ressources Humaines','RH','Gestion des ressources humaines et du personnel',1,'2026-02-17 11:44:53.331269','2026-02-17 11:47:00.365629',8,1),
(2,'Finance','FINANCE','Gestion financière et comptabilité',1,'2026-02-17 11:44:54.450507','2026-02-17 11:46:58.291301',9,1),
(3,'Commercial','COMMERCIAL','Département commercial et ventes',1,'2026-02-17 11:44:56.294519','2026-02-17 11:46:58.031395',10,1),
(4,'Technique','TECHNIQUE','Département technique et informatique',1,'2026-02-17 11:44:57.992253','2026-02-17 11:47:00.391227',11,1),
(5,'Logistique','LOGISTIQUE','Gestion logistique et approvisionnements',1,'2026-02-17 11:44:58.818430','2026-02-17 11:46:58.524486',12,1),
(6,'Direction','DIRECTION','Direction générale',1,'2026-02-17 11:44:59.808809','2026-02-17 11:46:58.074637',13,1),
(7,'RH','rh-cam','',1,'2026-02-17 17:34:22.833054','2026-02-17 17:34:22.833077',45,4),
(8,'WFM','WFM','',1,'2026-02-17 17:46:41.988648','2026-02-20 11:10:52.994118',46,4),
(9,'RH','rh-civ','',1,'2026-02-18 13:20:07.627878','2026-02-18 13:20:07.627964',49,3),
(10,'WFM','WFM','',1,'2026-02-20 09:53:46.683175','2026-02-20 09:54:05.414060',50,1),
(11,'WFM','WFM','',1,'2026-02-20 09:54:23.234603','2026-02-20 09:54:23.234702',51,2),
(12,'WFM','WFM','',1,'2026-02-20 09:54:41.347739','2026-02-20 09:54:41.347816',52,3),
(13,'WFM','WFM','',1,'2026-02-20 09:55:00.148075','2026-02-20 09:55:00.148154',53,6),
(14,'WFM','WFM','',1,'2026-02-20 09:55:14.826299','2026-02-20 09:55:14.826379',54,7);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_users_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_clockedschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_clockedschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_beat_clockedschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clocked_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_clockedschedule`
--

LOCK TABLES `django_celery_beat_clockedschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_clockedschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_clockedschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_crontabschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_crontabschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_beat_crontabschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `minute` varchar(240) NOT NULL,
  `hour` varchar(96) NOT NULL,
  `day_of_week` varchar(64) NOT NULL,
  `day_of_month` varchar(124) NOT NULL,
  `month_of_year` varchar(64) NOT NULL,
  `timezone` varchar(63) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_crontabschedule`
--

LOCK TABLES `django_celery_beat_crontabschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_crontabschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_crontabschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_intervalschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_intervalschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_beat_intervalschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `every` int(11) NOT NULL,
  `period` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_intervalschedule`
--

LOCK TABLES `django_celery_beat_intervalschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_intervalschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_intervalschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_periodictask`
--

DROP TABLE IF EXISTS `django_celery_beat_periodictask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_beat_periodictask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `task` varchar(200) NOT NULL,
  `args` longtext NOT NULL,
  `kwargs` longtext NOT NULL,
  `queue` varchar(200) DEFAULT NULL,
  `exchange` varchar(200) DEFAULT NULL,
  `routing_key` varchar(200) DEFAULT NULL,
  `expires` datetime(6) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `last_run_at` datetime(6) DEFAULT NULL,
  `total_run_count` int(10) unsigned NOT NULL CHECK (`total_run_count` >= 0),
  `date_changed` datetime(6) NOT NULL,
  `description` longtext NOT NULL,
  `crontab_id` int(11) DEFAULT NULL,
  `interval_id` int(11) DEFAULT NULL,
  `solar_id` int(11) DEFAULT NULL,
  `one_off` tinyint(1) NOT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `priority` int(10) unsigned DEFAULT NULL CHECK (`priority` >= 0),
  `headers` longtext NOT NULL,
  `clocked_id` int(11) DEFAULT NULL,
  `expire_seconds` int(10) unsigned DEFAULT NULL CHECK (`expire_seconds` >= 0),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `django_celery_beat_p_crontab_id_d3cba168_fk_django_ce` (`crontab_id`),
  KEY `django_celery_beat_p_interval_id_a8ca27da_fk_django_ce` (`interval_id`),
  KEY `django_celery_beat_p_solar_id_a87ce72c_fk_django_ce` (`solar_id`),
  KEY `django_celery_beat_p_clocked_id_47a69f82_fk_django_ce` (`clocked_id`),
  CONSTRAINT `django_celery_beat_p_clocked_id_47a69f82_fk_django_ce` FOREIGN KEY (`clocked_id`) REFERENCES `django_celery_beat_clockedschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_crontab_id_d3cba168_fk_django_ce` FOREIGN KEY (`crontab_id`) REFERENCES `django_celery_beat_crontabschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_interval_id_a8ca27da_fk_django_ce` FOREIGN KEY (`interval_id`) REFERENCES `django_celery_beat_intervalschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_solar_id_a87ce72c_fk_django_ce` FOREIGN KEY (`solar_id`) REFERENCES `django_celery_beat_solarschedule` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_periodictask`
--

LOCK TABLES `django_celery_beat_periodictask` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_periodictask` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_periodictask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_periodictasks`
--

DROP TABLE IF EXISTS `django_celery_beat_periodictasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_beat_periodictasks` (
  `ident` smallint(6) NOT NULL,
  `last_update` datetime(6) NOT NULL,
  PRIMARY KEY (`ident`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_periodictasks`
--

LOCK TABLES `django_celery_beat_periodictasks` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_periodictasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_periodictasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_solarschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_solarschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_beat_solarschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(24) NOT NULL,
  `latitude` decimal(9,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq` (`event`,`latitude`,`longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_solarschedule`
--

LOCK TABLES `django_celery_beat_solarschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_solarschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_solarschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_chordcounter`
--

DROP TABLE IF EXISTS `django_celery_results_chordcounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_results_chordcounter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` varchar(255) NOT NULL,
  `sub_tasks` longtext NOT NULL,
  `count` int(10) unsigned NOT NULL CHECK (`count` >= 0),
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_chordcounter`
--

LOCK TABLES `django_celery_results_chordcounter` WRITE;
/*!40000 ALTER TABLE `django_celery_results_chordcounter` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_results_chordcounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_groupresult`
--

DROP TABLE IF EXISTS `django_celery_results_groupresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_results_groupresult` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` varchar(255) NOT NULL,
  `date_created` datetime(6) NOT NULL,
  `date_done` datetime(6) NOT NULL,
  `content_type` varchar(128) NOT NULL,
  `content_encoding` varchar(64) NOT NULL,
  `result` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`),
  KEY `django_cele_date_cr_bd6c1d_idx` (`date_created`),
  KEY `django_cele_date_do_caae0e_idx` (`date_done`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_groupresult`
--

LOCK TABLES `django_celery_results_groupresult` WRITE;
/*!40000 ALTER TABLE `django_celery_results_groupresult` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_results_groupresult` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_taskresult`
--

DROP TABLE IF EXISTS `django_celery_results_taskresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_celery_results_taskresult` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `content_type` varchar(128) NOT NULL,
  `content_encoding` varchar(64) NOT NULL,
  `result` longtext DEFAULT NULL,
  `date_done` datetime(6) NOT NULL,
  `traceback` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `task_args` longtext DEFAULT NULL,
  `task_kwargs` longtext DEFAULT NULL,
  `task_name` varchar(255) DEFAULT NULL,
  `worker` varchar(100) DEFAULT NULL,
  `date_created` datetime(6) NOT NULL,
  `periodic_task_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `django_cele_task_na_08aec9_idx` (`task_name`),
  KEY `django_cele_status_9b6201_idx` (`status`),
  KEY `django_cele_worker_d54dd8_idx` (`worker`),
  KEY `django_cele_date_cr_f04a50_idx` (`date_created`),
  KEY `django_cele_date_do_f59aad_idx` (`date_done`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_taskresult`
--

LOCK TABLES `django_celery_results_taskresult` WRITE;
/*!40000 ALTER TABLE `django_celery_results_taskresult` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_results_taskresult` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES
(1,'admin','logentry'),
(3,'auth','group'),
(2,'auth','permission'),
(18,'common','auditlog'),
(4,'contenttypes','contenttype'),
(11,'django_celery_beat','clockedschedule'),
(6,'django_celery_beat','crontabschedule'),
(7,'django_celery_beat','intervalschedule'),
(8,'django_celery_beat','periodictask'),
(9,'django_celery_beat','periodictasks'),
(10,'django_celery_beat','solarschedule'),
(13,'django_celery_results','chordcounter'),
(14,'django_celery_results','groupresult'),
(12,'django_celery_results','taskresult'),
(20,'documents','document'),
(19,'documents','documentspecification'),
(24,'documents','documenttemplate'),
(21,'documents','documentvalidationresult'),
(22,'documents','filetypeconfiguration'),
(23,'documents','filetyperequirement'),
(25,'documents','templatedownloadlog'),
(26,'documents','templateversion'),
(27,'folders','folder'),
(30,'notifications','notification'),
(29,'routing_rules','departmentdocumenttype'),
(28,'routing_rules','routingrule'),
(5,'sessions','session'),
(17,'users','branch'),
(16,'users','department'),
(15,'users','user');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES
(1,'contenttypes','0001_initial','2026-02-17 11:25:53.424319'),
(2,'contenttypes','0002_remove_content_type_name','2026-02-17 11:26:07.711545'),
(3,'auth','0001_initial','2026-02-17 11:27:12.817807'),
(4,'auth','0002_alter_permission_name_max_length','2026-02-17 11:27:25.867163'),
(5,'auth','0003_alter_user_email_max_length','2026-02-17 11:27:25.894264'),
(6,'auth','0004_alter_user_username_opts','2026-02-17 11:27:25.963098'),
(7,'auth','0005_alter_user_last_login_null','2026-02-17 11:27:26.010519'),
(8,'auth','0006_require_contenttypes_0002','2026-02-17 11:27:26.116018'),
(9,'auth','0007_alter_validators_add_error_messages','2026-02-17 11:27:27.958997'),
(10,'auth','0008_alter_user_username_max_length','2026-02-17 11:27:28.000939'),
(11,'auth','0009_alter_user_last_name_max_length','2026-02-17 11:27:29.101283'),
(12,'auth','0010_alter_group_name_max_length','2026-02-17 11:27:36.132673'),
(13,'auth','0011_update_proxy_permissions','2026-02-17 11:27:39.844184'),
(14,'auth','0012_alter_user_first_name_max_length','2026-02-17 11:27:41.609899'),
(15,'users','0001_initial','2026-02-17 11:29:06.855805'),
(16,'admin','0001_initial','2026-02-17 11:29:37.554314'),
(17,'admin','0002_logentry_remove_auto_add','2026-02-17 11:29:39.412941'),
(18,'admin','0003_logentry_add_action_flag_choices','2026-02-17 11:29:40.143472'),
(19,'common','0001_initial','2026-02-17 11:30:50.393475'),
(20,'common','0002_alter_auditlog_ip_address','2026-02-17 11:31:02.201247'),
(21,'django_celery_beat','0001_initial','2026-02-17 11:31:52.383866'),
(22,'django_celery_beat','0002_auto_20161118_0346','2026-02-17 11:32:05.972311'),
(23,'django_celery_beat','0003_auto_20161209_0049','2026-02-17 11:32:11.573935'),
(24,'django_celery_beat','0004_auto_20170221_0000','2026-02-17 11:32:12.566480'),
(25,'django_celery_beat','0005_add_solarschedule_events_choices','2026-02-17 11:32:16.131796'),
(26,'django_celery_beat','0006_auto_20180322_0932','2026-02-17 11:32:40.914878'),
(27,'django_celery_beat','0007_auto_20180521_0826','2026-02-17 11:33:01.228635'),
(28,'django_celery_beat','0008_auto_20180914_1922','2026-02-17 11:33:01.772842'),
(29,'django_celery_beat','0006_auto_20180210_1226','2026-02-17 11:33:03.653135'),
(30,'django_celery_beat','0006_periodictask_priority','2026-02-17 11:33:11.797308'),
(31,'django_celery_beat','0009_periodictask_headers','2026-02-17 11:33:15.613524'),
(32,'django_celery_beat','0010_auto_20190429_0326','2026-02-17 11:33:15.879324'),
(33,'django_celery_beat','0011_auto_20190508_0153','2026-02-17 11:33:38.097612'),
(34,'django_celery_beat','0012_periodictask_expire_seconds','2026-02-17 11:33:47.245876'),
(35,'django_celery_beat','0013_auto_20200609_0727','2026-02-17 11:33:48.886141'),
(36,'django_celery_beat','0014_remove_clockedschedule_enabled','2026-02-17 11:33:55.670991'),
(37,'django_celery_beat','0015_edit_solarschedule_events_choices','2026-02-17 11:33:57.646353'),
(38,'django_celery_beat','0016_alter_crontabschedule_timezone','2026-02-17 11:33:59.011743'),
(39,'django_celery_beat','0017_alter_crontabschedule_month_of_year','2026-02-17 11:34:00.406583'),
(40,'django_celery_beat','0018_improve_crontab_helptext','2026-02-17 11:34:02.283261'),
(41,'django_celery_results','0001_initial','2026-02-17 11:34:12.503289'),
(42,'django_celery_results','0002_add_task_name_args_kwargs','2026-02-17 11:34:35.707095'),
(43,'django_celery_results','0003_auto_20181106_1101','2026-02-17 11:34:36.358989'),
(44,'django_celery_results','0004_auto_20190516_0412','2026-02-17 11:34:59.364170'),
(45,'django_celery_results','0005_taskresult_worker','2026-02-17 11:35:18.243114'),
(46,'django_celery_results','0006_taskresult_date_created','2026-02-17 11:35:39.940924'),
(47,'django_celery_results','0007_remove_taskresult_hidden','2026-02-17 11:35:48.574570'),
(48,'django_celery_results','0008_chordcounter','2026-02-17 11:35:57.582905'),
(49,'django_celery_results','0009_groupresult','2026-02-17 11:37:22.342112'),
(50,'django_celery_results','0010_remove_duplicate_indices','2026-02-17 11:37:24.183228'),
(51,'django_celery_results','0011_taskresult_periodic_task_name','2026-02-17 11:37:27.704834'),
(52,'users','0002_add_file_type_requirements','2026-02-17 11:37:34.627039'),
(53,'folders','0001_initial','2026-02-17 11:37:40.554255'),
(54,'folders','0002_initial','2026-02-17 11:38:07.303517'),
(55,'users','0003_add_department_model','2026-02-17 11:38:21.379973'),
(56,'users','0004_fix_department_fk','2026-02-17 11:38:26.578870'),
(57,'users','0005_add_branch_model','2026-02-17 11:38:34.527428'),
(58,'routing_rules','0001_initial','2026-02-17 11:38:35.085833'),
(59,'routing_rules','0002_initial','2026-02-17 11:38:39.453559'),
(60,'routing_rules','0003_departmentdocumenttype','2026-02-17 11:38:51.560099'),
(61,'routing_rules','0004_departmentdocumenttype_target_folder','2026-02-17 11:39:08.069871'),
(62,'documents','0001_initial','2026-02-17 11:40:45.303764'),
(63,'documents','0002_refactor_document_workflow','2026-02-17 11:40:48.195118'),
(64,'documents','0003_filetypeconfiguration','2026-02-17 11:40:49.061781'),
(65,'documents','0004_add_file_type_requirements','2026-02-17 11:40:50.786709'),
(66,'documents','0005_alter_document_document_type','2026-02-17 11:40:50.856009'),
(67,'documents','0006_add_templates','2026-02-17 11:41:00.553272'),
(68,'documents','0007_add_document_templates','2026-02-17 11:41:00.749835'),
(69,'notifications','0001_initial','2026-02-17 11:41:01.519707'),
(70,'notifications','0002_initial','2026-02-17 11:41:03.228159'),
(71,'notifications','0003_alter_notification_type_choices','2026-02-17 11:41:03.277547'),
(72,'notifications','0004_alter_notification_notification_type','2026-02-17 11:41:03.342676'),
(73,'routing_rules','0005_alter_departmentdocumenttype_department','2026-02-17 11:41:03.393885'),
(74,'routing_rules','0006_add_branch_to_routing_rule','2026-02-17 11:41:04.294947'),
(75,'routing_rules','0007_departmentdocumenttype_file_type_configuration','2026-02-17 11:41:04.953255'),
(76,'sessions','0001_initial','2026-02-17 11:41:05.477976'),
(77,'documents','0008_alter_document_document_type','2026-02-18 10:45:16.205693');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_specifications`
--

DROP TABLE IF EXISTS `document_specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_specifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `document_type` varchar(30) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `allowed_formats` varchar(255) NOT NULL,
  `requires_excel` tinyint(1) NOT NULL,
  `excel_sheet_name` varchar(100) NOT NULL,
  `required_columns` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`required_columns`)),
  `max_file_size_mb` int(11) NOT NULL,
  `max_rows` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `requires_validation` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `document_type` (`document_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_specifications`
--

LOCK TABLES `document_specifications` WRITE;
/*!40000 ALTER TABLE `document_specifications` DISABLE KEYS */;
INSERT INTO `document_specifications` VALUES
(1,'FACTURE','Facture','','pdf,xlsx',0,'','[]',50,100000,1,1,'2026-02-17 14:36:33.245314','2026-02-17 14:36:33.245343'),
(2,'BON_COMMANDE','Bon de Commande','','pdf,xlsx',0,'','[]',50,100000,1,1,'2026-02-17 14:36:33.565953','2026-02-17 14:36:33.566034'),
(3,'CONTRAT','Contrat','','pdf,docx',0,'','[]',50,100000,1,1,'2026-02-17 14:36:35.425344','2026-02-17 14:36:35.425467'),
(4,'RAPPORT','Rapport','','pdf,docx',0,'','[]',50,100000,1,1,'2026-02-17 14:36:35.498579','2026-02-17 14:36:35.498665'),
(5,'AUTRE','Autre Document','','pdf,xlsx,docx',0,'','[]',50,100000,1,1,'2026-02-17 14:36:36.124003','2026-02-17 14:36:36.124079'),
(6,'CONGE','Congé','','pdf,doc,docx',0,'','[]',35,100000,1,0,'2026-02-18 11:41:51.029257','2026-02-18 11:41:51.029373');
/*!40000 ALTER TABLE `document_specifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_validation_results`
--

DROP TABLE IF EXISTS `document_validation_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_validation_results` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` varchar(10) NOT NULL,
  `errors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`errors`)),
  `warnings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`warnings`)),
  `validation_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`validation_details`)),
  `validated_at` datetime(6) NOT NULL,
  `document_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `document_id` (`document_id`),
  CONSTRAINT `document_validation_results_document_id_9192e560_fk_documents_id` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_validation_results`
--

LOCK TABLES `document_validation_results` WRITE;
/*!40000 ALTER TABLE `document_validation_results` DISABLE KEYS */;
INSERT INTO `document_validation_results` VALUES
(1,'FAILED','[\"Erreur lors du traitement du fichier Excel: File is not a zip file\"]','[]','{}','2026-02-17 14:54:48.335879',1),
(2,'PASSED','[]','[\"Format XLS (ancien): Support basique uniquement. Recommandation: Convertissez en XLSX (.xlsx) pour une meilleure compatibilit\\u00e9.\"]','{\"format_type\": \"Excel XLS (ancien format, xlrd)\", \"sheet_names\": [\"Sheet1\"], \"sheet_count\": 1, \"row_count\": 10, \"column_count\": 8}','2026-02-17 14:55:50.705217',2),
(3,'PASSED','[]','[]','{\"file_format\": \"pdf\", \"file_size\": 245087}','2026-02-17 15:04:20.874889',3),
(4,'PASSED','[]','[\"Format XLS (ancien): Support basique uniquement. Recommandation: Convertissez en XLSX (.xlsx) pour une meilleure compatibilit\\u00e9.\"]','{\"format_type\": \"Excel XLS (ancien format, xlrd)\", \"sheet_names\": [\"Sheet1\"], \"sheet_count\": 1, \"row_count\": 10, \"column_count\": 8}','2026-02-17 18:56:46.619942',4),
(5,'PASSED','[]','[\"Format XLS (ancien): Support basique uniquement. Recommandation: Convertissez en XLSX (.xlsx) pour une meilleure compatibilit\\u00e9.\"]','{\"format_type\": \"Excel XLS (ancien format, xlrd)\", \"sheet_names\": [\"Sheet1\"], \"sheet_count\": 1, \"row_count\": 10, \"column_count\": 8}','2026-02-17 19:25:26.624174',5),
(6,'PASSED','[]','[\"Format XLS (ancien): Support basique uniquement. Recommandation: Convertissez en XLSX (.xlsx) pour une meilleure compatibilit\\u00e9.\"]','{\"format_type\": \"Excel XLS (ancien format, xlrd)\", \"sheet_names\": [\"Sheet1\"], \"sheet_count\": 1, \"row_count\": 10, \"column_count\": 8}','2026-02-18 08:27:00.398024',6),
(7,'PASSED','[]','[]','{\"file_format\": \"pdf\", \"file_size\": 245087}','2026-02-18 11:50:42.742516',7);
/*!40000 ALTER TABLE `document_validation_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `file` varchar(100) NOT NULL,
  `document_type` varchar(30) NOT NULL,
  `description` longtext NOT NULL,
  `status` varchar(20) NOT NULL,
  `accepted_at` datetime(6) DEFAULT NULL,
  `rejection_reason` longtext NOT NULL,
  `file_size` int(11) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_format` varchar(20) NOT NULL,
  `excel_sheet_name` varchar(100) NOT NULL,
  `excel_row_count` int(11) NOT NULL,
  `excel_column_count` int(11) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `routed_automatically` tinyint(1) NOT NULL,
  `agent_id` bigint(20) NOT NULL,
  `folder_id` bigint(20) DEFAULT NULL,
  `routing_rule_applied_id` bigint(20) DEFAULT NULL,
  `specification_id` bigint(20) DEFAULT NULL,
  `archived_at` datetime(6) DEFAULT NULL,
  `opened_at` datetime(6) DEFAULT NULL,
  `rejected_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_agent_i_7be503_idx` (`agent_id`,`status`),
  KEY `documents_documen_0d20f5_idx` (`document_type`,`created_at`),
  KEY `documents_folder__8cd630_idx` (`folder_id`,`status`),
  KEY `documents_routing_rule_applied_id_60233cbc_fk_routing_rules_id` (`routing_rule_applied_id`),
  KEY `documents_specification_id_ef428eb3_fk_document_` (`specification_id`),
  KEY `documents_status_497c5a_idx` (`status`,`created_at`),
  CONSTRAINT `documents_agent_id_04c183a2_fk_users_id` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`),
  CONSTRAINT `documents_folder_id_b5f2f4e5_fk_folders_id` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`),
  CONSTRAINT `documents_routing_rule_applied_id_60233cbc_fk_routing_rules_id` FOREIGN KEY (`routing_rule_applied_id`) REFERENCES `routing_rules` (`id`),
  CONSTRAINT `documents_specification_id_ef428eb3_fk_document_` FOREIGN KEY (`specification_id`) REFERENCES `document_specifications` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES
(1,'Test XLSX Upload','documents/temp/ADMIN001_20260217_145447.xlsx','BON_COMMANDE','Test upload','REJETE',NULL,'Erreur lors du traitement du fichier Excel: File is not a zip file',2100,'application/octet-stream','xlsx','',0,0,'2026-02-17 14:54:48.327842','2026-02-17 14:54:48.427467',0,11,NULL,NULL,2,NULL,NULL,NULL),
(2,'erp','documents/temp/BS002_20260217_145550.xls','BON_COMMANDE','','VALIDE','2026-02-17 15:05:45.593207','',8704,'application/vnd.ms-excel','xls','',0,0,'2026-02-17 14:55:50.632843','2026-02-17 14:55:53.332718',0,14,NULL,NULL,2,NULL,NULL,NULL),
(3,'bio','documents/temp/ADMIN001_20260217_150420.pdf','BON_COMMANDE','','VALIDE','2026-02-17 15:18:30.504694','',245087,'application/pdf','pdf','',0,0,'2026-02-17 15:04:20.868213','2026-02-17 15:04:22.708479',0,11,NULL,NULL,2,NULL,NULL,NULL),
(4,'bir','documents/temp/AG0001_20260217_185646.xls','AUTRE','','VALIDE','2026-02-17 19:00:30.200502','',8704,'application/vnd.ms-excel','xls','',0,0,'2026-02-17 18:56:46.600001','2026-02-17 18:56:48.847237',0,13,NULL,NULL,5,NULL,NULL,NULL),
(5,'sur','documents/temp/AG0001_20260217_192526.xls','AUTRE','','VALIDE','2026-02-17 19:49:29.284254','',8704,'application/vnd.ms-excel','xls','',0,0,'2026-02-17 19:25:26.618984','2026-02-17 19:25:26.660538',0,13,NULL,NULL,5,NULL,NULL,NULL),
(6,'rs','documents/temp/AG0001_20260218_082700.xls','AUTRE','','REJETE',NULL,'Rejeté par l\'administrateur',8704,'application/vnd.ms-excel','xls','',0,0,'2026-02-18 08:27:00.320288','2026-02-18 08:27:01.059813',0,13,NULL,NULL,5,NULL,NULL,'2026-02-20 11:22:14.669906'),
(7,'ok','documents/temp/AG0001_20260218_115041.pdf','AUTRE','','VALIDE','2026-02-20 11:22:19.847119','',245087,'application/pdf','pdf','',0,0,'2026-02-18 11:50:41.186007','2026-02-18 11:50:42.777366',0,13,47,NULL,5,NULL,NULL,NULL),
(8,'test5','documents/temp/AG0001_20260218_120641.pdf','CONGE','','EN_ATTENTE',NULL,'',245087,'application/pdf','pdf','',0,0,'2026-02-18 12:06:41.093646','2026-02-18 12:06:41.105406',0,13,48,NULL,6,NULL,NULL,NULL);
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_documenttemplate`
--

DROP TABLE IF EXISTS `documents_documenttemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_documenttemplate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `template_type` varchar(20) NOT NULL,
  `file` varchar(100) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `file_type` varchar(20) NOT NULL,
  `visibility` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `downloads_count` int(11) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `version` int(11) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_d_created_d8e05e_idx` (`created_by_id`,`created_at` DESC),
  KEY `documents_d_visibil_16ceee_idx` (`visibility`,`is_active`),
  KEY `documents_d_templat_02b3bb_idx` (`template_type`),
  CONSTRAINT `documents_documenttemplate_created_by_id_fce09d26_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_documenttemplate`
--

LOCK TABLES `documents_documenttemplate` WRITE;
/*!40000 ALTER TABLE `documents_documenttemplate` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_documenttemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_documenttemplate_allowed_users`
--

DROP TABLE IF EXISTS `documents_documenttemplate_allowed_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_documenttemplate_allowed_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `documenttemplate_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `documents_documenttempla_documenttemplate_id_user_6e5c0176_uniq` (`documenttemplate_id`,`user_id`),
  KEY `documents_documenttem_user_id_6212260e_fk_users_id` (`user_id`),
  CONSTRAINT `documents_documentte_documenttemplate_id_bf3f6482_fk_documents` FOREIGN KEY (`documenttemplate_id`) REFERENCES `documents_documenttemplate` (`id`),
  CONSTRAINT `documents_documenttem_user_id_6212260e_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_documenttemplate_allowed_users`
--

LOCK TABLES `documents_documenttemplate_allowed_users` WRITE;
/*!40000 ALTER TABLE `documents_documenttemplate_allowed_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_documenttemplate_allowed_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_documenttemplate_departments`
--

DROP TABLE IF EXISTS `documents_documenttemplate_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_documenttemplate_departments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `documenttemplate_id` bigint(20) NOT NULL,
  `department_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `documents_documenttempla_documenttemplate_id_depa_28fe624a_uniq` (`documenttemplate_id`,`department_id`),
  KEY `documents_documentte_department_id_de5087bc_fk_departmen` (`department_id`),
  CONSTRAINT `documents_documentte_department_id_de5087bc_fk_departmen` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `documents_documentte_documenttemplate_id_daeb9b9f_fk_documents` FOREIGN KEY (`documenttemplate_id`) REFERENCES `documents_documenttemplate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_documenttemplate_departments`
--

LOCK TABLES `documents_documenttemplate_departments` WRITE;
/*!40000 ALTER TABLE `documents_documenttemplate_departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_documenttemplate_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_templatedownloadlog`
--

DROP TABLE IF EXISTS `documents_templatedownloadlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_templatedownloadlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `downloaded_at` datetime(6) NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `template_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_templatedo_template_id_c69b3de9_fk_documents` (`template_id`),
  KEY `documents_templatedownloadlog_user_id_8d6cd0fd_fk_users_id` (`user_id`),
  CONSTRAINT `documents_templatedo_template_id_c69b3de9_fk_documents` FOREIGN KEY (`template_id`) REFERENCES `documents_documenttemplate` (`id`),
  CONSTRAINT `documents_templatedownloadlog_user_id_8d6cd0fd_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_templatedownloadlog`
--

LOCK TABLES `documents_templatedownloadlog` WRITE;
/*!40000 ALTER TABLE `documents_templatedownloadlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_templatedownloadlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents_templateversion`
--

DROP TABLE IF EXISTS `documents_templateversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents_templateversion` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version_number` int(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `changelog` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `template_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `documents_templateversio_template_id_version_numb_676ee882_uniq` (`template_id`,`version_number`),
  KEY `documents_templateversion_created_by_id_0deadbe9_fk_users_id` (`created_by_id`),
  CONSTRAINT `documents_templateve_template_id_47889f9c_fk_documents` FOREIGN KEY (`template_id`) REFERENCES `documents_documenttemplate` (`id`),
  CONSTRAINT `documents_templateversion_created_by_id_0deadbe9_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents_templateversion`
--

LOCK TABLES `documents_templateversion` WRITE;
/*!40000 ALTER TABLE `documents_templateversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents_templateversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_type_configurations`
--

DROP TABLE IF EXISTS `file_type_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_type_configurations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_type` varchar(20) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `max_file_size_mb` int(10) unsigned NOT NULL CHECK (`max_file_size_mb` >= 0),
  `min_file_size_kb` int(10) unsigned NOT NULL CHECK (`min_file_size_kb` >= 0),
  `max_rows` int(10) unsigned DEFAULT NULL CHECK (`max_rows` >= 0),
  `max_columns` int(10) unsigned DEFAULT NULL CHECK (`max_columns` >= 0),
  `max_sheets` int(10) unsigned DEFAULT NULL CHECK (`max_sheets` >= 0),
  `max_pages` int(10) unsigned DEFAULT NULL CHECK (`max_pages` >= 0),
  `max_width_px` int(10) unsigned DEFAULT NULL CHECK (`max_width_px` >= 0),
  `max_height_px` int(10) unsigned DEFAULT NULL CHECK (`max_height_px` >= 0),
  `min_width_px` int(10) unsigned DEFAULT NULL CHECK (`min_width_px` >= 0),
  `min_height_px` int(10) unsigned DEFAULT NULL CHECK (`min_height_px` >= 0),
  `require_macros_disabled` tinyint(1) NOT NULL,
  `require_no_password` tinyint(1) NOT NULL,
  `allow_external_links` tinyint(1) NOT NULL,
  `require_utf8_encoding` tinyint(1) NOT NULL,
  `allowed_sheets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`allowed_sheets`)),
  `forbidden_columns` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`forbidden_columns`)),
  `required_columns` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`required_columns`)),
  `is_enabled` tinyint(1) NOT NULL,
  `is_auto_validated` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_type` (`file_type`),
  KEY `file_type_configurations_created_by_id_77b54bdc_fk_users_id` (`created_by_id`),
  CONSTRAINT `file_type_configurations_created_by_id_77b54bdc_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_type_configurations`
--

LOCK TABLES `file_type_configurations` WRITE;
/*!40000 ALTER TABLE `file_type_configurations` DISABLE KEYS */;
INSERT INTO `file_type_configurations` VALUES
(1,'xls','Excel','',50,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,'[]','[]','[]',1,1,'2026-02-17 14:48:31.876492','2026-02-17 14:51:36.581132',NULL),
(2,'pdf','PDF','',50,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,'[]','[]','[]',1,1,'2026-02-17 14:53:58.987326','2026-02-17 14:53:58.987356',NULL),
(3,'xlsx','Excel XLSX','',50,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,'[]','[]','[]',1,1,'2026-02-17 14:54:00.162864','2026-02-17 14:58:12.152159',NULL),
(4,'docx','Word DOCX','',500,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,'[]','[]','[]',1,1,'2026-02-17 14:54:00.530047','2026-02-17 17:43:19.088704',NULL),
(5,'csv','CSV','',50,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,'[]','[]','[]',1,1,'2026-02-17 14:54:00.554335','2026-02-17 17:43:15.200954',NULL),
(6,'xlsb','XLSB','',502,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,'[]','[]','[]',1,1,'2026-02-17 17:38:51.647166','2026-02-17 17:38:51.647242',NULL),
(7,'xlsm','Exel XLSM','',5000,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,'[]','[]','[]',1,1,'2026-02-17 17:40:25.646177','2026-02-17 17:40:25.646199',NULL);
/*!40000 ALTER TABLE `file_type_configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_type_requirements`
--

DROP TABLE IF EXISTS `file_type_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_type_requirements` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `max_file_size_mb` int(10) unsigned DEFAULT NULL CHECK (`max_file_size_mb` >= 0),
  `is_required` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `file_type_config_id` bigint(20) NOT NULL,
  `routing_rule_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_type_requirements_routing_rule_id_file_typ_3a9fb962_uniq` (`routing_rule_id`,`file_type_config_id`),
  KEY `file_type_requiremen_file_type_config_id_792dbb84_fk_file_type` (`file_type_config_id`),
  CONSTRAINT `file_type_requiremen_file_type_config_id_792dbb84_fk_file_type` FOREIGN KEY (`file_type_config_id`) REFERENCES `file_type_configurations` (`id`),
  CONSTRAINT `file_type_requiremen_routing_rule_id_49e2e28b_fk_routing_r` FOREIGN KEY (`routing_rule_id`) REFERENCES `routing_rules` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_type_requirements`
--

LOCK TABLES `file_type_requirements` WRITE;
/*!40000 ALTER TABLE `file_type_requirements` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_type_requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folders`
--

DROP TABLE IF EXISTS `folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `folders_name_parent_id_6f0c5d0e_uniq` (`name`,`parent_id`),
  KEY `folders_created_by_id_829125e0_fk_users_id` (`created_by_id`),
  KEY `folders_parent_id_bd43fe3e_fk_folders_id` (`parent_id`),
  CONSTRAINT `folders_created_by_id_829125e0_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `folders_parent_id_bd43fe3e_fk_folders_id` FOREIGN KEY (`parent_id`) REFERENCES `folders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders`
--

LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
INSERT INTO `folders` VALUES
(1,'Bénin','Dossier racine de la filiale Bénin (BEN)','2026-02-17 11:44:25.615149','2026-02-17 11:44:25.615233',1,NULL,NULL),
(2,'Congo','Dossier racine de la filiale Congo (CON)','2026-02-17 11:44:31.822478','2026-02-17 11:44:31.822571',1,NULL,NULL),
(3,'Côte d\'Ivoire','Dossier racine de la filiale Côte d\'Ivoire (CIV)','2026-02-17 11:44:34.064174','2026-02-17 11:44:34.064252',1,NULL,NULL),
(4,'Cameroun','Dossier racine de la filiale Cameroun (CAM)','2026-02-17 11:44:35.664082','2026-02-17 11:44:35.664157',1,NULL,NULL),
(5,'Guinée Équatoriale','Dossier racine de la filiale Guinée Équatoriale (GEQ)','2026-02-17 11:44:37.430602','2026-02-17 11:44:37.430681',1,NULL,NULL),
(6,'Guinée','Dossier racine de la filiale Guinée (GUI)','2026-02-17 11:44:41.088870','2026-02-17 11:44:41.088947',1,NULL,NULL),
(7,'Guinée-Bissau','Dossier racine de la filiale Guinée-Bissau (GBS)','2026-02-17 11:44:46.663631','2026-02-17 11:44:46.663709',1,NULL,NULL),
(8,'Ressources Humaines','Dossier racine du département Ressources Humaines','2026-02-17 11:44:53.362928','2026-02-17 14:02:08.981766',1,NULL,1),
(9,'Finance','Dossier racine du département Finance','2026-02-17 11:44:54.451073','2026-02-17 14:02:06.878074',1,NULL,1),
(10,'Commercial','Dossier racine du département Commercial','2026-02-17 11:44:56.300004','2026-02-17 14:02:06.833537',1,NULL,1),
(11,'Technique','Dossier racine du département Technique','2026-02-17 11:44:57.994075','2026-02-17 14:02:07.781469',1,NULL,1),
(12,'Logistique','Dossier racine du département Logistique','2026-02-17 11:44:58.820052','2026-02-17 14:02:07.889150',1,NULL,1),
(13,'Direction','Dossier racine du département Direction','2026-02-17 11:44:59.810434','2026-02-17 14:02:07.273155',1,NULL,1),
(14,'FACTURE','Dossier pour les documents de type FACTURE','2026-02-17 14:38:09.630474','2026-02-17 14:38:09.630559',1,NULL,10),
(15,'BON_COMMANDE','Dossier pour les documents de type BON_COMMANDE','2026-02-17 14:38:10.598836','2026-02-17 14:38:10.598919',1,NULL,10),
(16,'Contrat','Dossier pour les documents de type Contrat','2026-02-17 14:38:12.456524','2026-02-17 14:38:12.456602',1,NULL,10),
(17,'Rapport d\'activité','Dossier pour les documents de type Rapport d\'activité','2026-02-17 14:38:13.488539','2026-02-17 14:38:13.488618',1,NULL,10),
(18,'Autre','Dossier pour les documents de type Autre','2026-02-17 14:38:15.378991','2026-02-17 14:38:15.379073',1,NULL,10),
(19,'FACTURE','Dossier pour les documents de type FACTURE','2026-02-17 14:38:17.213224','2026-02-17 14:38:17.213298',1,NULL,13),
(20,'BON_COMMANDE','Dossier pour les documents de type BON_COMMANDE','2026-02-17 14:38:17.311586','2026-02-17 14:38:17.311659',1,NULL,13),
(21,'Contrat','Dossier pour les documents de type Contrat','2026-02-17 14:38:17.538064','2026-02-17 14:38:17.538163',1,NULL,13),
(22,'Rapport d\'activité','Dossier pour les documents de type Rapport d\'activité','2026-02-17 14:38:19.404712','2026-02-17 14:38:19.404785',1,NULL,13),
(23,'Autre','Dossier pour les documents de type Autre','2026-02-17 14:38:20.970284','2026-02-17 14:38:20.970357',1,NULL,13),
(24,'FACTURE','Dossier pour les documents de type FACTURE','2026-02-17 14:38:23.922434','2026-02-17 14:38:23.922514',1,NULL,9),
(25,'BON_COMMANDE','Dossier pour les documents de type BON_COMMANDE','2026-02-17 14:38:27.666784','2026-02-17 14:38:27.666861',1,NULL,9),
(26,'Contrat','Dossier pour les documents de type Contrat','2026-02-17 14:38:27.820734','2026-02-17 14:38:27.820811',1,NULL,9),
(27,'Rapport d\'activité','Dossier pour les documents de type Rapport d\'activité','2026-02-17 14:38:28.319763','2026-02-17 14:38:28.319839',1,NULL,9),
(28,'Autre','Dossier pour les documents de type Autre','2026-02-17 14:38:28.547929','2026-02-17 14:38:28.548009',1,NULL,9),
(29,'FACTURE','Dossier pour les documents de type FACTURE','2026-02-17 14:38:28.786467','2026-02-17 14:38:28.786540',1,NULL,12),
(30,'BON_COMMANDE','Dossier pour les documents de type BON_COMMANDE','2026-02-17 14:38:29.011375','2026-02-17 14:38:29.011450',1,NULL,12),
(31,'Contrat','Dossier pour les documents de type Contrat','2026-02-17 14:38:30.864593','2026-02-17 14:38:30.864695',1,NULL,12),
(32,'Rapport d\'activité','Dossier pour les documents de type Rapport d\'activité','2026-02-17 14:38:31.140590','2026-02-17 14:38:31.140631',1,NULL,12),
(33,'Autre','Dossier pour les documents de type Autre','2026-02-17 14:38:31.185402','2026-02-17 14:38:31.185447',1,NULL,12),
(34,'FACTURE','Dossier pour les documents de type FACTURE','2026-02-17 14:38:32.001318','2026-02-17 14:38:32.001393',1,NULL,8),
(35,'BON_COMMANDE','Dossier pour les documents de type BON_COMMANDE','2026-02-17 14:38:32.079829','2026-02-17 14:38:32.079906',1,NULL,8),
(36,'Contrat','Dossier pour les documents de type Contrat','2026-02-17 14:38:32.270346','2026-02-17 14:38:32.270367',1,NULL,8),
(37,'Rapport d\'activité','Dossier pour les documents de type Rapport d\'activité','2026-02-17 14:38:33.656359','2026-02-17 14:38:33.656388',1,NULL,8),
(38,'Autre','Dossier pour les documents de type Autre','2026-02-17 14:38:35.503507','2026-02-17 14:38:35.503581',1,NULL,8),
(39,'FACTURE','Dossier pour les documents de type FACTURE','2026-02-17 14:38:37.363346','2026-02-17 14:38:37.363414',1,NULL,11),
(40,'BON_COMMANDE','Dossier pour les documents de type BON_COMMANDE','2026-02-17 14:38:38.005243','2026-02-17 14:38:38.005318',1,NULL,11),
(41,'Contrat','Dossier pour les documents de type Contrat','2026-02-17 14:38:39.026343','2026-02-17 14:38:39.026418',1,NULL,11),
(42,'Rapport d\'activité','Dossier pour les documents de type Rapport d\'activité','2026-02-17 14:38:41.988312','2026-02-17 14:38:41.988387',1,NULL,11),
(43,'Autre','Dossier pour les documents de type Autre','2026-02-17 14:38:42.245103','2026-02-17 14:38:42.245125',1,NULL,11),
(45,'RH','Dossier racine du département RH','2026-02-17 17:34:24.680149','2026-02-17 17:34:24.680217',1,NULL,4),
(46,'WFM','Dossier racine du département WFM','2026-02-17 17:46:42.254754','2026-02-17 17:46:42.254825',1,NULL,4),
(47,'Autre','Dossier pour les documents de type Autre','2026-02-18 11:50:41.226322','2026-02-18 11:50:41.226401',1,NULL,45),
(48,'Demande de congé','Dossier pour les documents de type Demande de congé','2026-02-18 12:05:48.141196','2026-02-18 12:05:48.141217',1,NULL,45),
(49,'RH','Dossier racine du département RH','2026-02-18 13:20:09.053991','2026-02-18 13:20:09.054065',1,NULL,3),
(50,'QUALITE','Dossier racine du département WFM','2026-02-20 09:53:47.063488','2026-02-20 11:24:32.862436',1,NULL,NULL),
(51,'WFM','Dossier racine du département WFM','2026-02-20 09:54:24.342005','2026-02-20 09:54:24.342075',1,NULL,2),
(52,'WFM','Dossier racine du département WFM','2026-02-20 09:54:42.577814','2026-02-20 09:54:42.577886',1,NULL,3),
(53,'WFM','Dossier racine du département WFM','2026-02-20 09:55:01.118865','2026-02-20 09:55:01.118939',1,NULL,6),
(54,'WFM','Dossier racine du département WFM','2026-02-20 09:55:15.951666','2026-02-20 09:55:15.951738',1,NULL,7);
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `notification_type` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `is_read` tinyint(1) NOT NULL,
  `read_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `document_id` bigint(20) DEFAULT NULL,
  `recipient_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_document_id_5472c8e3_fk_documents_id` (`document_id`),
  KEY `notificatio_recipie_583549_idx` (`recipient_id`,`is_read`),
  KEY `notificatio_created_e4c995_idx` (`created_at`),
  CONSTRAINT `notifications_document_id_5472c8e3_fk_documents_id` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`),
  CONSTRAINT `notifications_recipient_id_e1133bac_fk_users_id` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,'VALIDATION','[ECHEC] Validation échouée','Votre document \'Test XLSX Upload\' n\'a pas passé la validation.\n\nProblèmes détectés:\n- Erreur lors du traitement du fichier Excel: File is not a zip file',0,NULL,'2026-02-17 14:54:48.425583',1,11),
(2,'DOCUMENT_UPLOADED','[SUCCES] Document uploadé','Votre document \'Test XLSX Upload\' a été uploadé avec succès et est en attente de validation.',0,NULL,'2026-02-17 14:54:48.448275',1,11),
(3,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Admin One a uploadé un nouveau document: \'Test XLSX Upload\'',0,NULL,'2026-02-17 14:54:49.336593',1,12),
(4,'VALIDATION','[SUCCES] Validation réussie','Votre document \'erp\' a été validé avec succès et attend l\'approbation d\'un administrateur.',0,NULL,'2026-02-17 14:55:52.256808',2,14),
(5,'VALIDATION','[VALIDATION] Document validé','Le document \'erp\' de l\'agent erp testj a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-17 14:55:52.277615',2,12),
(6,'VALIDATION','[VALIDATION] Document validé','Le document \'erp\' de l\'agent erp testj a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-17 14:55:53.330848',2,11),
(7,'DOCUMENT_UPLOADED','[SUCCES] Document uploadé','Votre document \'erp\' a été uploadé avec succès et est en attente de validation.',0,NULL,'2026-02-17 14:55:53.455081',2,14),
(8,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent erp testj a uploadé un nouveau document: \'erp\'',0,NULL,'2026-02-17 14:55:55.324095',2,12),
(9,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent erp testj a uploadé un nouveau document: \'erp\'',0,NULL,'2026-02-17 14:55:55.379262',2,11),
(10,'VALIDATION','[SUCCES] Validation réussie','Votre document \'bio\' a été validé avec succès et attend l\'approbation d\'un administrateur.',0,NULL,'2026-02-17 15:04:22.697608',3,11),
(11,'VALIDATION','[VALIDATION] Document validé','Le document \'bio\' de l\'agent Admin One a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-17 15:04:22.704913',3,12),
(12,'VALIDATION','[VALIDATION] Document validé','Le document \'bio\' de l\'agent Admin One a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-17 15:04:22.706713',3,11),
(13,'DOCUMENT_UPLOADED','[SUCCES] Document uploadé','Votre document \'bio\' a été uploadé avec succès et est en attente de validation.',0,NULL,'2026-02-17 15:04:24.636793',3,11),
(14,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Admin One a uploadé un nouveau document: \'bio\'',0,NULL,'2026-02-17 15:04:26.499941',3,12),
(15,'DOCUMENT_APPROVED','[SUCCES] Document approuvé','Vous avez approuvé le document \'erp\' de l\'agent erp testj.',0,NULL,'2026-02-17 15:05:45.632760',2,11),
(16,'DOCUMENT_APPROVED','[ACTION] Document approuvé','L\'administrateur Admin One a approuvé le document \'erp\' de l\'agent erp testj.',0,NULL,'2026-02-17 15:05:45.792450',2,12),
(17,'DOCUMENT_APPROVED','[VALIDEE] Document approuvé','Votre document \'erp\' a été approuvé par l\'administrateur Admin One.',0,NULL,'2026-02-17 15:05:45.807523',2,14),
(18,'DOCUMENT_APPROVED','[SUCCES] Document approuvé','Vous avez approuvé le document \'bio\' de l\'agent Admin One.',0,NULL,'2026-02-17 15:18:31.874533',3,11),
(19,'DOCUMENT_APPROVED','[ACTION] Document approuvé','L\'administrateur Admin One a approuvé le document \'bio\' de l\'agent Admin One.',0,NULL,'2026-02-17 15:18:33.254331',3,12),
(20,'DOCUMENT_APPROVED','[VALIDEE] Document approuvé','Votre document \'bio\' a été approuvé par l\'administrateur Admin One.',0,NULL,'2026-02-17 15:18:33.440644',3,11),
(21,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'Test XLSX Upload\'.',0,NULL,'2026-02-17 15:35:47.518867',1,11),
(22,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bio\'.',0,NULL,'2026-02-17 15:36:11.347061',3,11),
(23,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bio\'.',0,NULL,'2026-02-17 15:36:49.662618',3,11),
(24,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bio\'.',0,NULL,'2026-02-17 17:30:28.808322',3,11),
(25,'VALIDATION','[SUCCES] Validation réussie','Votre document \'bir\' a été validé avec succès et attend l\'approbation d\'un administrateur.',0,NULL,'2026-02-17 18:56:47.988766',4,13),
(26,'VALIDATION','[VALIDATION] Document validé','Le document \'bir\' de l\'agent Agent Ones a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-17 18:56:48.835907',4,12),
(27,'VALIDATION','[VALIDATION] Document validé','Le document \'bir\' de l\'agent Agent Ones a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-17 18:56:48.837598',4,11),
(28,'DOCUMENT_UPLOADED','[SUCCES] Document uploadé','Votre document \'bir\' a été uploadé avec succès et est en attente de validation.',0,NULL,'2026-02-17 18:56:48.880938',4,13),
(29,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'bir\'',0,NULL,'2026-02-17 18:56:50.711492',4,12),
(30,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'bir\'',0,NULL,'2026-02-17 18:56:52.139221',4,11),
(31,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bir\'.',0,NULL,'2026-02-17 18:59:59.481274',4,13),
(32,'DOCUMENT_APPROVED','[SUCCES] Document approuvé','Vous avez approuvé le document \'bir\' de l\'agent Agent Ones.',0,NULL,'2026-02-17 19:00:32.031101',4,11),
(33,'DOCUMENT_APPROVED','[ACTION] Document approuvé','L\'administrateur Admin One a approuvé le document \'bir\' de l\'agent Agent Ones.',0,NULL,'2026-02-17 19:00:33.013026',4,12),
(34,'DOCUMENT_APPROVED','[VALIDEE] Document approuvé','Votre document \'bir\' a été approuvé par l\'administrateur Admin One.',0,NULL,'2026-02-17 19:00:33.039478',4,13),
(35,'VALIDATION','[SUCCES] Validation réussie','Votre document \'sur\' a été validé avec succès et attend l\'approbation d\'un administrateur.',0,NULL,'2026-02-17 19:25:26.624733',5,13),
(36,'VALIDATION','[VALIDATION] Document validé','Le document \'sur\' de l\'agent Agent Ones a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-17 19:25:26.626318',5,12),
(37,'VALIDATION','[VALIDATION] Document validé','Le document \'sur\' de l\'agent Agent Ones a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-17 19:25:26.626744',5,11),
(38,'DOCUMENT_UPLOADED','[SUCCES] Document uploadé','Votre document \'sur\' a été uploadé avec succès et est en attente de validation.',0,NULL,'2026-02-17 19:25:26.735571',5,13),
(39,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'sur\'',0,NULL,'2026-02-17 19:25:26.770333',5,12),
(40,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'sur\'',0,NULL,'2026-02-17 19:25:26.827247',5,11),
(41,'DOCUMENT_APPROVED','[SUCCES] Document approuvé','Vous avez approuvé le document \'sur\' de l\'agent Agent Ones.',1,NULL,'2026-02-17 19:49:31.111127',5,11),
(42,'DOCUMENT_APPROVED','[ACTION] Document approuvé','L\'administrateur Admin One a approuvé le document \'sur\' de l\'agent Agent Ones.',1,NULL,'2026-02-17 19:49:31.326553',5,12),
(43,'DOCUMENT_APPROVED','[VALIDEE] Document approuvé','Votre document \'sur\' a été approuvé par l\'administrateur Admin One.',1,NULL,'2026-02-17 19:49:33.026061',5,13),
(44,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bir\'.',1,NULL,'2026-02-18 07:46:50.662942',4,13),
(45,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bir\'.',0,NULL,'2026-02-18 07:49:30.588631',4,13),
(46,'VALIDATION','[SUCCES] Validation réussie','Votre document \'rs\' a été validé avec succès et attend l\'approbation d\'un administrateur.',0,NULL,'2026-02-18 08:27:00.631924',6,13),
(47,'VALIDATION','[VALIDATION] Document validé','Le document \'rs\' de l\'agent Agent Ones a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-18 08:27:01.057553',6,12),
(48,'VALIDATION','[VALIDATION] Document validé','Le document \'rs\' de l\'agent Agent Ones a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-18 08:27:01.058784',6,11),
(49,'DOCUMENT_UPLOADED','[SUCCES] Document uploadé','Votre document \'rs\' a été uploadé avec succès et est en attente de validation.',0,NULL,'2026-02-18 08:27:02.904536',6,13),
(50,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'rs\'',0,NULL,'2026-02-18 08:27:02.925389',6,12),
(51,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'rs\'',0,NULL,'2026-02-18 08:27:04.745705',6,11),
(52,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'sur\'.',0,NULL,'2026-02-18 08:47:39.067437',5,13),
(53,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'rs\'.',0,NULL,'2026-02-18 09:15:57.556661',6,13),
(54,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bio\'.',0,NULL,'2026-02-18 11:03:45.016238',3,11),
(55,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'rs\'.',0,NULL,'2026-02-18 11:04:43.756898',6,13),
(56,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'rs\'.',0,NULL,'2026-02-18 11:23:24.533994',6,13),
(57,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bir\'.',0,NULL,'2026-02-18 11:38:59.212589',4,13),
(58,'VALIDATION','[SUCCES] Validation réussie','Votre document \'ok\' a été validé avec succès et attend l\'approbation d\'un administrateur.',0,NULL,'2026-02-18 11:50:42.745706',7,13),
(59,'VALIDATION','[VALIDATION] Document validé','Le document \'ok\' de l\'agent Agent Ones a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-18 11:50:42.760858',7,12),
(60,'VALIDATION','[VALIDATION] Document validé','Le document \'ok\' de l\'agent Agent Ones a été validé avec succès et attend votre approbation.',0,NULL,'2026-02-18 11:50:42.770993',7,11),
(61,'DOCUMENT_UPLOADED','[SUCCES] Document uploadé','Votre document \'ok\' a été uploadé avec succès et est en attente de validation.',0,NULL,'2026-02-18 11:50:44.155215',7,13),
(62,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'ok\'',0,NULL,'2026-02-18 11:50:44.208247',7,12),
(63,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'ok\'',0,NULL,'2026-02-18 11:50:45.546478',7,11),
(64,'DOCUMENT_UPLOADED','[SUCCES] Document uploadé','Votre document \'test5\' a été uploadé avec succès et est en attente de validation.',0,NULL,'2026-02-18 12:06:41.939021',8,13),
(65,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'test5\'',0,NULL,'2026-02-18 12:06:43.362104',8,12),
(66,'DOCUMENT_UPLOADED','[NOUVEAU] Document reçu','L\'agent Agent Ones a uploadé un nouveau document: \'test5\'',0,NULL,'2026-02-18 12:06:43.694910',8,11),
(67,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'ok\'.',0,NULL,'2026-02-18 13:10:35.674353',7,13),
(68,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 13:44:47.045340',8,13),
(69,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'sur\'.',0,NULL,'2026-02-18 14:00:57.962323',5,13),
(70,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'ok\'.',0,NULL,'2026-02-18 14:01:16.511362',7,13),
(71,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 14:29:49.444767',8,13),
(72,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 15:02:59.680509',8,13),
(73,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'ok\'.',0,NULL,'2026-02-18 15:22:56.046233',7,13),
(74,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 15:29:00.600713',8,13),
(75,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 15:47:08.486706',8,13),
(76,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'ok\'.',0,NULL,'2026-02-18 15:47:30.956027',7,13),
(77,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 16:13:58.110193',8,13),
(78,'SYSTEM','Test Notification Generated','This is a test notification to verify the notification generation system works correctly',0,NULL,'2026-02-18 16:16:50.891366',NULL,11),
(79,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 16:47:57.441056',8,13),
(80,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 16:51:52.262450',8,13),
(81,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 17:07:42.648245',8,13),
(82,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',1,NULL,'2026-02-18 17:30:58.019629',8,13),
(83,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',1,NULL,'2026-02-18 17:31:43.228479',8,13),
(84,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'erp\'.',1,NULL,'2026-02-18 17:31:57.871190',2,14),
(85,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'bir\'.',1,NULL,'2026-02-18 17:32:05.864829',4,13),
(86,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',1,NULL,'2026-02-18 18:17:27.465625',8,13),
(87,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'ok\'.',0,NULL,'2026-02-18 19:26:42.582133',7,13),
(88,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-18 20:00:34.778110',8,13),
(89,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'ok\'.',0,NULL,'2026-02-19 08:19:55.898316',7,13),
(90,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-19 08:20:17.849085',8,13),
(91,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-19 08:20:29.245593',8,13),
(92,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'ok\'.',0,NULL,'2026-02-19 08:35:45.940893',7,13),
(93,'SYSTEM','Real-Time WebSocket Test','Redis connection working! Test at 2026-02-19 10:09:27.801791',0,NULL,'2026-02-19 09:09:27.802159',NULL,12),
(94,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'sur\'.',0,NULL,'2026-02-19 09:18:31.594482',5,13),
(95,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-19 10:31:25.546199',8,13),
(96,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'rs\'.',0,NULL,'2026-02-20 11:20:58.661940',6,13),
(97,'DOCUMENT_REJECTED','[REJET] Document rejeté','Vous avez rejeté le document \'rs\' de l\'agent Agent Ones.',0,NULL,'2026-02-20 11:22:16.141572',6,11),
(98,'DOCUMENT_REJECTED','[ACTION] Document rejeté','L\'administrateur Admin One a rejeté le document \'rs\' de l\'agent Agent Ones.',0,NULL,'2026-02-20 11:22:17.458935',6,12),
(99,'DOCUMENT_REJECTED','[ATTENTION] Document rejeté','Votre document \'rs\' a été rejeté par l\'administrateur Admin One.',0,NULL,'2026-02-20 11:22:17.514753',6,13),
(100,'DOCUMENT_APPROVED','[SUCCES] Document approuvé','Vous avez approuvé le document \'ok\' de l\'agent Agent Ones.',0,NULL,'2026-02-20 11:22:21.129906',7,11),
(101,'DOCUMENT_APPROVED','[ACTION] Document approuvé','L\'administrateur Admin One a approuvé le document \'ok\' de l\'agent Agent Ones.',0,NULL,'2026-02-20 11:22:21.214591',7,12),
(102,'DOCUMENT_APPROVED','[VALIDEE] Document approuvé','Votre document \'ok\' a été approuvé par l\'administrateur Admin One.',0,NULL,'2026-02-20 11:22:21.621080',7,13),
(103,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-20 11:22:25.642698',8,13),
(104,'DOCUMENT_OPENED','[DOWNLOAD] Document telecharge','L\'administrateur Admin One a telecharge votre document \'test5\'.',0,NULL,'2026-02-20 11:53:45.034156',8,13);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routing_rules`
--

DROP TABLE IF EXISTS `routing_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `routing_rules` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `conditions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`conditions`)),
  `priority` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `times_applied` int(11) NOT NULL,
  `last_applied` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `destination_folder_id` bigint(20) NOT NULL,
  `branch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `routing_rules_created_by_id_a92b60a5_fk_users_id` (`created_by_id`),
  KEY `routing_rules_destination_folder_id_200d61d8_fk_folders_id` (`destination_folder_id`),
  KEY `routing_rules_branch_id_8ce1e52f_fk_branches_id` (`branch_id`),
  CONSTRAINT `routing_rules_branch_id_8ce1e52f_fk_branches_id` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `routing_rules_created_by_id_a92b60a5_fk_users_id` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`),
  CONSTRAINT `routing_rules_destination_folder_id_200d61d8_fk_folders_id` FOREIGN KEY (`destination_folder_id`) REFERENCES `folders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routing_rules`
--

LOCK TABLES `routing_rules` WRITE;
/*!40000 ALTER TABLE `routing_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `routing_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `matricule` varchar(20) NOT NULL,
  `email` varchar(254) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `department` varchar(20) DEFAULT NULL,
  `role` varchar(10) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `avatar` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `department_id` bigint(20) DEFAULT NULL,
  `branch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matricule` (`matricule`),
  UNIQUE KEY `email` (`email`),
  KEY `users_department_id_f0b302db_fk_departments_id` (`department_id`),
  KEY `users_branch_id_d1b397ca_fk_branches_id` (`branch_id`),
  CONSTRAINT `users_branch_id_d1b397ca_fk_branches_id` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `users_department_id_f0b302db_fk_departments_id` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(11,'pbkdf2_sha256$600000$yFGW0Y9irMYnciaYyYjgVp$SVYLFsZnQNuYU7umPfCdhuE1jPdw1mBLc2vVerNsRc4=',1,'ADMIN001','admin001@test.com','Admin','One',NULL,'ADMIN','','',1,1,'2026-02-17 13:37:57.612945',NULL,8,4),
(12,'pbkdf2_sha256$600000$b23vXw3Ms1gGM2TxMeEwhp$OVD+sbVsjGqJxXO8bQMBjUD6GlsHkkD0GD7f13U+N3o=',1,'ADMIN002','admin002@test.com','Admin','Two',NULL,'ADMIN','','',1,1,'2026-02-17 13:37:59.368587',NULL,9,3),
(13,'pbkdf2_sha256$600000$awuof4ZlG0DHmCNxjnDTlR$EZYGcMTb1DsG+deM6H93DsBsi7OXh++ThxLjmFZuJ+8=',0,'AG0001','agent001@test.com','Agent','Ones',NULL,'AGENT','','',1,0,'2026-02-17 13:38:00.987669',NULL,7,4),
(14,'pbkdf2_sha256$600000$Benxd7mbUF74ZC2PyABrSL$XtfxIyv4jtbOJbokxLoLxMDOCr4XHh1wz1fWX0J0TGE=',0,'BS002','dede@ddwd.de','Agent','One',NULL,'AGENT','','',1,0,'2026-02-17 14:15:27.648240',NULL,4,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_groups_user_id_group_id_fc7788e8_uniq` (`user_id`,`group_id`),
  KEY `users_groups_group_id_2f3517aa_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_groups_group_id_2f3517aa_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `users_groups_user_id_f500bee5_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_user_permissions`
--

DROP TABLE IF EXISTS `users_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_permissions_user_id_permission_id_3b86cbdf_uniq` (`user_id`,`permission_id`),
  KEY `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_user_permissio_permission_id_6d08dcd2_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_user_permissions_user_id_92473840_fk_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_user_permissions`
--

LOCK TABLES `users_user_permissions` WRITE;
/*!40000 ALTER TABLE `users_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-20 18:30:13
